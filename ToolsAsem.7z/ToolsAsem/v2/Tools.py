# coding=<UTF-16>

import os
import sys
import xml.etree.ElementTree as ET

# Definición de variables global

ArchivosExtentos = list()

# Obtener archivo de variables
extension = ".hmirealtimedb"  # extensión archivo variables
archivos = os.listdir(".")    # lista de todos los archivos en el directorio actual

# Filtrar archivos con la extensión deseada
archivos_con_extension = [archivo for archivo in archivos if archivo.endswith(extension)]

# Obtener el nombre del primer archivo con la extensión deseada (si existe)
RutaArchivoVar = archivos_con_extension[0]

# Directorio raíz donde se desea buscar
directorio_raiz = "."

# Lista de extensiones de archivo a buscar
ExtensioesExtentas = [".hmirealtimedb", 
                      ".hmirefactoring", 
                      ".txt", 
                      ".log1", 
                      ".log2", 
                      ".log3", 
                      ".log4", 
                      ".log5", 
                      ".log6", 
                      ".log7", 
                      ".log8", 
                      ".log9", 
                      ".txt"]  # extensiones en las que no quiero buscar

# Recorrer el árbol de directorios de forma recursiva
for directorio_actual, subdirectorios, archivos in os.walk(directorio_raiz):
    # Filtrar los archivos con las extensiones deseadas
    AuxArchivosExtentos = [archivo for archivo in archivos if any(archivo.endswith(extension) for extension in ExtensioesExtentas)]
    # Imprimir los archivos encontrados en el directorio actual
    for archivo in AuxArchivosExtentos:
        ArchivosExtentos.append(archivo)

def VisualizarArchivosSinRev(ArchivosNoRevisados):

    if len(ArchivosNoRevisados) > 0:

        LogFilesSinRev = open("LOGS/FilesSinRev.txt", 'w')
        LogFilesSinRev.write("\n".join(ArchivosNoRevisados))
        LogFilesSinRev.close()
        print("Ha habido archivos que no se han podido revisar, se han guardado en LOGS/FilesSinRev.txt")
        rsp = input("¿Quieres verlos? (s/n)? ").lower()
        if rsp == "s":
            os.system("Notepad LOGS/FilesSinRev.txt")
    os.system("cls")

def BuscarEnProyecto(ElementosBuscados=list, Excepciones=list):

    ArchivosNoRevisados = list()
    ElementosSinUsar = list()
    CrossRef = list()

    # Compruebo en todos los archivos del proyecto si se utiliza alguna variable (los fors para buscar todos los archivos está fusilado de internet)
    for Elemento in ElementosBuscados:
        Encontrado = False
        for dirpath, dirnames, filenames in os.walk(os.getcwd()):
            for filename in filenames:
                if (not (filename in Excepciones) or len(Excepciones) == 0):
                    file_path = os.path.join(dirpath, filename)
                    try:
                        file = open(file_path, 'r', encoding="UTF-16")
                        for linea in file:
                            if Elemento in linea:
                                Encontrado = True
                                CrossRef.append(f'"{Elemento}" se usa en: "{dirpath}\\{filename}"')
                                continue
                            
                    except Exception as e:
                        ArchivosNoRevisados.append(dirpath + '\\' + filename)
        if not Encontrado:
            ElementosSinUsar.append(Elemento)

    ElementosSinUsar    = list(set(ElementosSinUsar))    # Quito duplicados
    ArchivosNoRevisados = list(set(ArchivosNoRevisados)) # Quito duplicados

    return CrossRef, ElementosSinUsar, ArchivosNoRevisados

def VarSinUsar():

    # definir varibles auxiliares
    ArchivosNoRevisados = list() # LLista de archivos no revisado por error al leerlo
    VarSinUsar          = list() # Lista variables sin usar
    ListaVar            = list() # Lista varible

    global ArchivosExtentos, RutaArchivoVar

    # definir la propiedad que queremos buscar
    NombreProp = 'Variable'

    # analizar el archivo XML y encontrar todos los hijos de la propiedad
    xml_tree = ET.parse(RutaArchivoVar)
    root     = xml_tree.getroot()

    for variable in root.iter(NombreProp):          # Extraer todos los elementos de tipo "Variable" del archivo de alarmas
        ListaVar.append(variable.find('Name').text) # Extraer los nombres de las variables

    CrossRef, VarSinUsar, ArchivosNoRevisados = BuscarEnProyecto(ListaVar, ArchivosExtentos)

    if len(VarSinUsar) > 0:

        print("Variales sin usar:")
        for Var in VarSinUsar:
            print(f' - {Var}')

        print('Las variables sin usar se han guardado en LOGS/VariablesSinUsar.txt')
            
        LogReport = open("LOGS/VariablesSinUsar.txt", 'w')
        LogReport.write("\n".join(VarSinUsar))
        LogReport.close()
    else:

        print("Todas las variables están utilizadas")
        rsp = input("¿Quieres visualizar donde se usa cada una? (s/n)").lower()
        if rsp == "s":
            LogCrossRef = open("LOGS/VariablesCrossRef.txt", 'w')
            LogCrossRef.write("\n".join(CrossRef))
            LogCrossRef.close()
            os.system("Notepad LOGS/VariablesCrossRef.txt")

        input("Pulse ENTER para finalizar")
        return

    # Visualizar los archivos no revisados
    VisualizarArchivosSinRev(ArchivosNoRevisados)

    rsp = input("¿Quieres eliminar las variables no usadas? (s/n)? ").lower()
    if rsp == "s":
        for Var in VarSinUsar:
            # Buscar y eliminar el elemento con el nombre Prueba1
            for var in root.findall("./VariableList/Variable"):
                name = var.find('Name')
                if name is not None and name.text == Var:
                    root.findall("./VariableList")[0].remove(var)

        # Guardar los cambios en el archivo XML
        xml_tree.write(RutaArchivoVar, encoding="UTF-16", xml_declaration=True, method="xml")
        os.system("cls")
        input(f'Ahora se abrirá el archivo de variables ({RutaArchivoVar}), cambia las simples comillas por comillas dobles en la primera linea, si no ASEM no reconoce las variables.')
        os.system("Notepad " + RutaArchivoVar)
    else:
        sys.exit()
        
    input("Pulse ENTER para finalizar")
    
def ImagenesSinUsar():
    
    # definir Imagenibles auxiliares
    ArchivosNoRevisados     = list() # LLista de archivos no revisado por error al leerlo
    ImagenesSinUsar         = list() # Lista Imageniables sin usar
    ListaImagen             = list() # Lista Imagenible

    global ArchivosExtentos

    # Obtener la lista de archivos en el subdirectorio "imagenes"
    ListaImagen = os.listdir("./IMAGES")

    CrossRef, ImagenesSinUsar, ArchivosNoRevisados = BuscarEnProyecto(ListaImagen, ArchivosExtentos)

    print("\n".join(CrossRef))

    if len(ImagenesSinUsar) > 0:

        print("Imagenes sin usar:")
        for Imagen in ImagenesSinUsar:
            print(f' - {Imagen}')

        print('Las imagenes sin usar se han guardado en LOGS/ImagenesSinUsar.txt')

        LogReport = open("LOGS/ImagenesSinUsar.txt", 'w')
        LogReport.write("\n".join(ImagenesSinUsar))

    else:
        print("Todas las variables están utilizadas")
        rsp = input("¿Quieres visualizar donde se usa cada una? (s/n)").lower()
        if rsp == "s":
            LogCrossRef = open("LOGS/ImagesCrossRef.txt", 'w')
            LogCrossRef.write("\n".join(CrossRef))
            LogCrossRef.close()
            os.system("Notepad LOGS/ImagesCrossRef.txt")
        input("Pulse ENTER para finalizar")
        return

    VisualizarArchivosSinRev(ArchivosNoRevisados)
    
    rsp = input("¿Quieres eliminar las imagenes no usadas? (s/n)? ").lower()
    if rsp == "s":
        for Imagen in ImagenesSinUsar:
            os.remove("./IMAGES/" + Imagen)
    else:
        sys.exit()

    input("Pulse ENTER para finalizar")

def main():

    # definir variables globales
    ArchivosNoRevisados = list()

    print("Selecciona la utlidad a ejecutar: ")
    print("1: Listar variables sin usar")
    print("2: Listar imágenes sin usar")

    UtilidadAEjecutar = int(input(""))

    os.system("cls")

    if UtilidadAEjecutar == 1:
        VarSinUsar()
    if UtilidadAEjecutar == 2:
        ImagenesSinUsar() 

if __name__ == '__main__':
    main()